import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-motivo-nodual',
  templateUrl: './delete-motivo-nodual.component.html',
  styleUrls: ['./delete-motivo-nodual.component.scss']
})
export class DeleteMotivoNodualComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
