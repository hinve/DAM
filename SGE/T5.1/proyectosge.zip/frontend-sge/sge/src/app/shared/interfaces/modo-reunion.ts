export interface ModoReunion {
	id_modo_reunion: string;
	modo_reunion: string;
	observaciones?: any;
  }