import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-unidad-dual',
  templateUrl: './edit-unidad-dual.component.html',
  styleUrls: ['./edit-unidad-dual.component.scss']
})
export class EditUnidadDualComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
