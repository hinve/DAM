import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-unidad-dual',
  templateUrl: './delete-unidad-dual.component.html',
  styleUrls: ['./delete-unidad-dual.component.scss']
})
export class DeleteUnidadDualComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
