import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-unidad-dual',
  templateUrl: './add-unidad-dual.component.html',
  styleUrls: ['./add-unidad-dual.component.scss']
})
export class AddUnidadDualComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
