import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-motivo-nodual',
  templateUrl: './add-motivo-nodual.component.html',
  styleUrls: ['./add-motivo-nodual.component.scss']
})
export class AddMotivoNodualComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
