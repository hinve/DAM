export interface Provincia {
    Id: string;
    Provincia: string;
    Observaciones?: string;
}