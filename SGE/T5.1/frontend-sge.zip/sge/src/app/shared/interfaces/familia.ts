export interface Familia {
	id_familia: string;
	familia: string;
	observaciones?: any;
  }