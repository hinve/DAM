export interface Rol {
    id_rol?: number;
    rol: string;
    observaciones: string;
}
