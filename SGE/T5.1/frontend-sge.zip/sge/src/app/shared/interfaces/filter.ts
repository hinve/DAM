import { FormControl } from '@angular/forms';

export interface Filter {
    filter: FormControl;
    filterValue: string;
}
