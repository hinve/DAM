export interface UnidadDual {
	id_unidad_dual: string;
	unidad_dual: string;
	observaciones?: any;
  }
  