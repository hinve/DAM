export interface TipoEntidad {
	id_tipo_entidad: string;
	tipo_entidad: string;
	observaciones?: any;
  }
  