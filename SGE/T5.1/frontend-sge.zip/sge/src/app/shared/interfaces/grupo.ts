export interface Grupo {
    id_grupo_menu?: number;
    grupo: string;
    orden: number;
    observaciones: string;
}
